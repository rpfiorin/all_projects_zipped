// Importa biblioteca
import styled from 'styled-components';

//export const P1 = styled.h6`
    //float: left
//`;
