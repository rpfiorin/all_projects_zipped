/**
 * 
 */
function submitForms(){
  document.getElementById("criarTutorial").submit();
 }
