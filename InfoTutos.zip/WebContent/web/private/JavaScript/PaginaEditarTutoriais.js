/**
 * 
 */

function submitForms(){
  document.getElementById("editarTutorial").submit();
 }
