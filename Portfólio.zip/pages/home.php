<!-- Conteudo do menu "Home" -->
<br/>
<h3>
    Seja bem-vindo ao meu portfólio online!
    <br/>
    O site passará por atualizações periodicamente.
</h3>
<br/><br/>
<h5>Fatos que interessam<br/><br/>
    <p>
        <a href="https://cio.com.br/9-profissionais-de-ti-mais-demandados-no-brasil-em-2019/" target="_blank">
        • Profissões da TI em alta no Brasil
        </a>
    </p>
    <p>
        <a href="https://link.estadao.com.br/noticias/empresas,sucesso-de-drones-atrai-interesse-de-empreendedores,10000055419" target="_blank">
        • O sucesso dos Drones no mercado
        </a>
    </p>
    <p>
        <a href="https://www.grupoescolar.com/pesquisa/dicas-de-ouro-para-ter-uma-vida-financeira-saudavel.html" target="_blank">
        • Dicas para uma vida financeira saudável
        </a>
    </p>  
    <p>
        <a href="https://www.hipercultura.com/o-que-e-e-como-desenvolver-sua-inteligencia-emocional/" target="_blank">
        • Inteligência emocional: Como desenvolvê-la
        </a>
    </p>  
    <p>
        <a href="https://www.terra.com.br/noticias/dino/autodidatismo-e-tendencia-entre-metodos-de-estudo,eb596ea2495c11a4c810c5d2b5656190di3olnek.html" target="_blank">
        • Autodidatismo em métodos de estudo
        </a>
    </p>
</h5>

