﻿CREATE DATABASE fiorin;

CREATE SCHEMA rpfiorin;

CREATE TABLE rpfiorin.sistema
(
 codigo SERIAL PRIMARY KEY,
 nome TEXT NOT NULL,
 versao VARCHAR(12) NOT NULL,
 dt_inicio DATE NOT NULL,
 dt_fim DATE
);