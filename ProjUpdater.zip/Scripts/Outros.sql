﻿--Reseta a sequência da tabela.
TRUNCATE TABLE rpfiorin.sistema
RESTART IDENTITY;