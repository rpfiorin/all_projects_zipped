﻿--Cria o usuário que acessará o banco pelo sistema,
CREATE USER u_projupdater PASSWORD 'Pr0jUpd@t&r';
--Insere usuário do sistema ao grupo,
ALTER GROUP g_sistemas ADD USER u_projupdater;
--Dá privilégios ao usuário no schema,
GRANT ALL ON SCHEMA rpfiorin TO g_sistemas;
--Dá privilégios a ele na tabela,
GRANT ALL ON rpfiorin.sistema TO g_sistemas;
--Libera inserção de sistemas,
GRANT ALL ON rpfiorin.sistema_codigo_seq TO g_sistemas;
