﻿CREATE TABLE rpfiorin.evento
(
 descricao TEXT NOT NULL,
 data date NOT NULL,
 horario VARCHAR(15) NOT NULL,
 local VARCHAR(40) NOT NULL,
 is_ativo BOOLEAN NOT NULL
);
 