// Importa classes do react 
import React from 'react';

function Home() {
    return (
        <div>
            <br/><br/><br/><br/><br/><br/> 
            <p className="mt-5 text-center">
                <h1>Seja bem-vindo</h1><br/>✨
            </p>
        </div>
    )
}

// Exporta
export default Home;