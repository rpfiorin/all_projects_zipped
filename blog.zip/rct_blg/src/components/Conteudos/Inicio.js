// Importa classes do react 
import React from 'react';

function Inicio() {
    return (
        <div className="container">
            <h2>
            <br/><br/>  
                <p className="mt-2 text-left">
                    É um prazer recebê-lo em meu site pessoal!
                </p>
            </h2>
            <h3>
                <p className="mt-4 text-left">➥&nbsp;
                    Continue no menu acima para navegar.<br/> 
                </p>
            </h3>
        </div>
    )
}

// Exporta
export default Inicio;