// Importa classes do react 
import React, { Profiler } from 'react';

function Portfolio() {
    return (
        <div className="container">
            <h2>
            <br/><br/>
                <p className="mt-2 text-left">
                   Fique à vontade:
                </p>
            </h2>
            <h3>
                <p className="mt-4 text-left">
                    ➦&nbsp; 
                    <a href="http://rpfiorin.rf.gd" target="_blank">
                        Visite aqui.    
                    </a>
                </p>
            </h3>
        </div>
    )
}

// Exporta
export default Portfolio;