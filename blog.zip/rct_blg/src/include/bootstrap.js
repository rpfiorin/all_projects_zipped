// Importa as dependencias
import './jquery';
import './popper';

// Importa o BS
import 'bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';