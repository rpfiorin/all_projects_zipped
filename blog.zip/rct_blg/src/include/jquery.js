// Importa conteudo da biblioteca (dando nome de "$")
import * as $ from 'jquery';

// Permite utilizar "$" como seletor
window.jQuery = window.$ = $;

