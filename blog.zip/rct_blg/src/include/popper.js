// Importa a lib
import Popper from 'popper.js';

// Permite utilizar como seletor
window.Popper = Popper;
