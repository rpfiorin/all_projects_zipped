<!-- Conteudo do menu "Projetos" -->
<br/>
<h3>Estes são alguns dos projetos que desenvolvi por meio de minhas experiências acadêmico-profissionais:</h3>
<center>
        <img class="mySlides" src="img/projects/Acessos.png">
        <img class="mySlides" src="img/projects/PrjUp.png">
        <img class="mySlides" src="img/projects/NF.png">
        <img class="mySlides" src="img/projects/Sup.png">
        <img class="mySlides" src="img/projects/InfTut.png">
        <img class="mySlides" src="img/projects/PizDC.png">
    <br/>
        <button class="w3-button w3-display-left" onclick="plusDivs(-1)">&#10094;</button>
        <button class="w3-button w3-display-right" onclick="plusDivs(+1)">&#10095;</button>
    <br/><br/>
    <br/><br/>
</center>
    <br/>
    <h4>
    	• Alguns dos códigos-fonte podem ser acessados em: 
    	<a href="https://github.com/rpfiorin/projects" target="_blank">github.com/rpfiorin/projects</a>
    </h4>  
 <br/><br/>
 <br/><br/> 